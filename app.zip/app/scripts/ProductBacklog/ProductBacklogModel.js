/* ProductBacklog */

/*app.ProductBacklog.Model = app.BacklogItem.Model;*/

app.ProductBacklog.Model = app.BacklogItem.Model.extend({});