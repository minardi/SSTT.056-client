/* Teams */

(function(module) {

    module.Model = Backbone.Model.extend({

        defaults: {
            name: "",
            description: "",
        }

    });
    
})(app.Teams);
