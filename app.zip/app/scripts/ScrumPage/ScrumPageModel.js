/* ScrumPage */

(function(module) {
        
	module.Model = Backbone.Model.extend({	     
		 
		defaults: {
			id_of_project: ""
        }		 
	});

})(app.ScrumPage);
