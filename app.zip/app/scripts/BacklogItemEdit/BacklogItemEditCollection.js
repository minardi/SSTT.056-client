/* BacklogItemEdit */

(function(module) {
        
    module.Collection = Backbone.Collection.extend({	     
        model: module.Model,

        url: "",

        initialize: function() {
        }		 

    });

})(app.BacklogItemEdit);

