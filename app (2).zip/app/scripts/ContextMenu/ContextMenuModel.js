/* ContextMenu */

(function(module) {

    module.Model = Backbone.Model.extend({

        defaults: {
            btn_content: "",
            btn_type: "",
            permission: {}
        }
    });

})(app.ContextMenu);
