/* ScrumPage */

(function(module) {
        
	module.Model = Backbone.Model.extend({	     
		 
		defaults: {
			project_id: ""
        }		 
	});

})(app.ScrumPage);
