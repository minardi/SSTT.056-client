/* InfoblockModel */

(function(module) {

    module.Model = Backbone.Model.extend({});

})(app.InfoBlock);