/* Teams */

(function(module) {

    module.ModelView = Backbone.View.extend({

        tagName: "div",
        
        className: "box", 

        template: JST['app/scripts/Teams/TeamsTpl.ejs'],
        
        events: {
            "dblclick": "selectTeam",
			"click": "chooseTeam"
        },
		
		chooseTeam: function() {
			mediator.pub("TeamPage:TeamChoosed", this.model, "team");
		},

        selectTeam: function() {
            mediator.pub("TeamPage:TeamSelected", this.model.id);
        },

        render: function() {
            this.$el.html(this.template(this.model.toJSON()));
            return this;
        }

    });

})(app.Teams);
