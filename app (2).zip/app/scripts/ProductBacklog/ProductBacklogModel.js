/* ProductBacklog */

app.ProductBacklog.Model = app.BacklogItem.Model;