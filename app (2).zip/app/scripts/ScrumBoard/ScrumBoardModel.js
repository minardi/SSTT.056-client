/* ScrumBoard */

app.ScrumBoard.Model = app.BacklogItem.Model;
