/* ScrumBoard */

app.ScrumBoard.Collection = app.BacklogItem.Collection;