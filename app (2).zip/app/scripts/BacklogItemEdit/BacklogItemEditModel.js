/* BacklogItemEdit */

(function(module) {
        
    module.Model = app.BacklogItem.Model;

})(app.BacklogItemEdit);
