/* Statistics */

app.Statistics.Collection = app.BacklogItem.Collection;
