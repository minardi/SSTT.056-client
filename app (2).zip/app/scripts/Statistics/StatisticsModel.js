/* Statistics */

app.Statistics.Model = app.BacklogItem.Model;
